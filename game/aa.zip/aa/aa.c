#include<stdio.h>
#include<string.h>
#include<math.h>
/*size of map*/

char map_state[100][100];

int map_row,map_col;
void read_state();
void display_state();
void get_coordinates(int *row, int *col, char element);

int move_pacman1(int pr,int pc);

int move_ghost(int ghost_row,int ghost_col, int pr,int pc);
int get_ghost_dir_least(float left_dis,float right_dis,float up_dis,float down_dis);
int get_ghost_dir_highest(float left_dis,float right_dis,float up_dis,float down_dis);

int main()
{
	int i,pr,pc,gr[4],gc[4],pacman,g[4];
	FILE *fp1;
	read_state();
	/*coordinates of pacman and ghosts*/
	get_coordinates(&pr,&pc,'P');
	
	get_coordinates(gr,gc,'G');
		
	pacman=move_pacman1(pr,pc);
	
	for(i=0;i<4;i++)
	{	
		g[i]=0;
		if(gr[i]!=-1||gc[i]!=-1)
		{
			g[i]=move_ghost(gr[i],gc[i],pr,pc);
		}
	}
	//fp1=fopen("aa/move.txt", "w+");
	//fprintf(fp1,"%d %d %d %d %d",g[0],g[1],g[2],g[3],pacman);
	//printf("%d %d %d %d %d",g[0],g[1],g[2],g[3]);
	printf("%d %d %d %d %d",g[0],g[1],g[2],g[3],pacman);
	return 0;
}

void read_state()
{
	int i,j;	
	FILE *fp;
	//fp=fopen("aa/state.txt", "r");
	scanf("%d",&map_row);
	scanf("%d",&map_col);
	for(i=0;i<map_row;i++)
	{	
		for(j=0;j<map_col;j++)
		{
			scanf("%c ",&map_state[i][j]); 
		}
	}
}
/*to get coordinates for characters*/
void get_coordinates(int *row, int *col, char element)
{
	int i,j;
	int ghost_count=0;
	*row=-1;*col=-1;
	for(i=0;i<4;i++)
	{
		row[i]=-1;col[i]=-1;
	}
	if(element!='P'&&element!='G'&&element!='Q') {return;}
	if(element=='P'||element=='Q')
	{
	for(i=0;i<map_row;i++)
	{
		for(j=0;j<map_col;j++)
		{
			if(map_state[i][j]==element)
				{
					*row=i;*col=j;
					return;	
				}		
		}
	}
		*row=-1;*col=-1;
	}
	else
	{
		for (i=0;i<map_row;i++)
		{
			for(j=0;j<=map_col;j++)
			{
				if(map_state[i][j]=='A'||map_state[i][j]=='B'||map_state[i][j]=='C'||map_state[i][j]=='D')
				{
					row[ghost_count]=i;col[ghost_count]=j;
					ghost_count++;
					if(ghost_count==4) return;
					
				}		
			}
		}
	}	


}
/*Return the move for pacman*/
int move_pacman1(int pr,int pc)
{
	int pleft_row,pleft_col,pright_row,pright_col,pup_col,pup_row,pdown_row,pdown_col;

	pleft_row=pr;
	pleft_col=pc-1;

	pright_row=pr;
	pright_col=pc+1;
		
	pup_row=pr-1;
	pup_col=pc;

	pdown_row=pr+1;
	pdown_col=pc;
	

	if(map_state[pleft_row][pleft_col]!='W'&&(map_state[pleft_row][pleft_col]!='A'||map_state[pleft_row][pleft_col]!='B'||map_state[pleft_row][pleft_col]!='C'||map_state[pleft_row][pleft_col]!='D'))
		return 3;

	else if(map_state[pright_row][pright_col]!='W'&&(map_state[pright_row][pright_col]!='A'||map_state[pright_row][pright_col]!='B'||map_state[pright_row][pright_col]!='C'||map_state[pright_row][pright_col]!='D'))
		return 4;

	else if(map_state[pup_row][pup_col]!='W'&&(map_state[pup_row][pup_col]!='A'||map_state[pup_row][pup_col]!='B'||map_state[pup_row][pup_col]!='C'||map_state[pup_row][pup_col]!='D'))
		return 1;

	else 
		return 2;
	
}

/*Return the move for ghots*/
int move_ghost(int ghost_row,int ghost_col,int pr, int pc)
{

	
	int gleft_row, gleft_col,gright_row,gright_col,gup_row, gup_col, gdown_row, gdown_col;
	float left_dis=-1,right_dis=-1,up_dis=-1,down_dis=-1;

	gleft_row=ghost_row;
	gleft_col=ghost_col-1;
	
	gright_row=ghost_row;
	gright_col=ghost_col+1;
	
	gup_row=ghost_row-1;
	gup_col=ghost_col;

	gdown_row=ghost_row+1;
	gdown_col=ghost_col;



	if(map_state[gright_row][gright_col]!='W'&&(map_state[gright_row][gright_col]!='A'||map_state[gright_row][gright_col]!='B'||map_state[gright_row][gright_col]!='C'||map_state[gright_row][gright_col]!='D'))
		return 4;

	else if(map_state[gleft_row][gleft_col]!='W'&&(map_state[gleft_row][gleft_col]!='A'||map_state[gleft_row][gleft_col]!='B'||map_state[gleft_row][gleft_col]!='C'||map_state[gleft_row][gleft_col]!='D'))
		return 3;


	else if(map_state[gup_row][gup_col]!='W'&&(map_state[gup_row][gup_col]!='A'||map_state[gup_row][gup_col]!='B'||map_state[gup_row][gup_col]!='C'||map_state[gup_row][gup_col]!='D'))
		return 1;

	else 
		return 2;

	
}

